# Índice de Memória do Projeto

> Última atualização: Etapa 19 (Correções pós-entrega — e-mail real, celular por código numérico, DataProtection, contrato de módulos)

## O que é este diretório

Registro cumulativo de decisões, contextos e pendências de cada etapa do
desenvolvimento. A regra de trabalho é: **antes de iniciar qualquer etapa,
leia este índice e as memórias já existentes** para não repetir nem contradizer
decisões já tomadas. Ao final de cada etapa, crie/atualize a memória da etapa e
este índice.

## Projeto

**Serviço:** Identity & Tenants (primeiro microsserviço da plataforma)
**Papel:** cadastro de Tenants, Filiais (Branches) e toda a
Identidade/Autenticação/Autorização consumida via JWT pelos demais serviços.

## Histórico de Etapas

| Etapa | Arquivo | Status | Resumo |
|-------|---------|--------|--------|
| 00 | `etapa-00-base-da-memoria.md` | Feita | Estrutura `docs/memoria/` criada |
| 01 | `etapa-01-estrutura-e-docker.md` | Feita | Solução .slnx + Clean Architecture + Dockerfile/compose + user-secrets |
| 02 | `etapa-02-dominio-tenant-branch.md` | Feita | DDD Tenant/Branch + VOs validados + EF Core + migration + índice único CNPJ |
| 03 | `etapa-03-identity-roles-jwt.md` | Feita | Identity custom (ApplicationUser/Role) + seed de roles + JWT RS256 + JWKS + login/refresh (implementada, registrada retroativamente) |
| 04 | `etapa-04-regras-unicidade.md` | Feita | Regras de unicidade multi-tenant (índices + validators + describer pt-BR) |
| 05 | `etapa-05-sso-google-facebook.md` | Feita | Login social Google/Facebook exclusivo Client + cookie intermediário + JWT próprio |
| 06 | `etapa-06-confirmacao-email-sms.md` | Feita | Confirmação de e-mail (tokens Identity) + SMS (Twilio trial) + claims/policy de conta ativa |
| 07 | `etapa-07-cache-logging-observabilidade.md` | Feita | Cache (IMemoryCache + Valkey/Redis), Serilog + Correlation ID, health checks, rate limiting em auth, métricas Identity/Prometheus |
| 08 | `etapa-08-docker-final.md` | Feita | Dockerfile multi-stage (non-root), rede `identity-net`, compose base/override, env via `.env`, README com fluxo de subida |
| 09 | `etapa-09-docs-testes-handoff.md` | Feita | OpenAPI nativo 3.1 + Bearer + SwaggerUI, `CONTRATO-IDENTIDADE.md`, suíte de integração (Testcontainers) com cobertura |
| 10 | `etapa-10-credenciais-scalar.md` | Feita | Guia de credenciais externas (`docs/CONFIGURACAO-CREDENCIAIS.md`) + troca do SwaggerUI pelo Scalar (Bearer na UI em /scalar) |
| 11 | `etapa-11-gestao-conta.md` | **Feita (final)** | Gestão completa da conta: `register` (Client autosserviço), `forgot-password` e-mail/SMS, `reset-password`, `change-password`, `logout`, `logout-all`, expirações de token documentadas |
| 12 | `etapa-12-dominio-e-crud-plans.md` | **Feita (final)** | Domínio `Plan` + CRUD exclusivo SuperAdmin (`/api/plans`), soft delete (named query filter), FluentValidation, paginação, 45/45 testes |
| 13 | `etapa-13-crud-tenants.md` | **Feita (final)** | CRUD de Tenants (`/api/tenants`, SuperAdmin) + FK `plan_id` opcional (decisão do usuário), soft delete com índice parcial de CNPJ/e-mail, filtros de listagem, bloqueio de auth de tenants soft-deletados, 64/64 testes |
| 14 | `etapa-14-crud-filiais.md` | **Feita (final)** | CRUD de Filiais aninhado em `/api/tenants/{tenantId}/branches`, **autorização por claim do JWT** (SuperAdmin qualquer tenant; TenantAdmin só o próprio, 403 se rota ≠ claim), soft delete no Branch, garantia de não-vazamento entre tenants, 82/82 testes |
| 15 | `etapa-15-modulos-e-planos-por-modulo.md` | **Feita (final)** | Módulos (`/api/modules`, slug estável/imutável) + planos **por módulo** (`/api/modules/{moduleId}/plans`, nome único por módulo) + vínculo tenant↔module (`/api/tenants/{tenantId}/modules`, **SuperAdmin-only**) com histórico de vigências e troca de plano; `Tenant.PlanId` removido (Etapa 13 substituída por `tenant_modules`), migration defensiva com backfill, 111/111 testes |
| 16 | `etapa-16-fluxo-de-cadastro.md` | **Feita (final)** | Etapa de documentação: `docs/FLUXO-DE-CADASTRO.md` (ordem oficial Module → Plan por Module → Tenant → vínculo → Branch → Usuários), `docs/CONTRATO-IDENTIDADE.md` reescrito (estado atual da API: modules/plans por módulo/vínculos; removidas rotas planas obsoletas), contrato recomendado `GET /api/tenants/me/modules` documentado (pendência Etapa 15 retomada), README com link do fluxo; nenhuma mudança de código |
| 17 | `etapa-17-tenant-cpf-ou-cnpj.md` | **Feita (final)** | **Correção da Etapa 02**: Tenant deixa de ser CNPJ-only e passa a aceitar **CPF ou CNPJ** (`TipoPessoa` + VO `Documento`, reutilizando `Cpf`/`Cnpj`); unicidade global **por número** (`IX_tenants_documento`, independente do tipo); `CreateTenantCommand`/`TenantDto`/`ListTenantsQuery` e filtro `?documento=`; mensagens diferenciadas CPF/CNPJ; migration defensiva com backfill (existente = Juridica); `PtBrIdentityErrorDescriber` inalterado; 115/115 testes |
| 18 | `etapa-18-seed-inicial.md` | **Feita (final)** | **Bootstrap da plataforma**: `DbSeeder` idempotente (Module `core` → Plan Full Access → Tenant SmartSync Platform → Branch → vínculo → SuperAdmin global `sa@smartsync.com.br`); **convenção `null` = "sem limite"** nos limites do plano (`int` → `int?`, migration `MakePlanLimitsNullable`); senha via `SEED_SUPERADMIN_PASSWORD` (default só em Development); `IdentitySeeder` volta a ser só migrations+roles; docs/config migradas de `admin@identity.local` para `sa@smartsync.com.br`; `docs/SEED-INICIAL.md`; 118/118 testes |
| 19 | `etapa-19-correcoes-pos-entrega.md` | **Feita (final)** | **Correções pós-entrega**: e-mail real (Gmail SMTP, log de sucesso, `resend` loga motivo, link de confirmação → API + `GET /confirm-email` com página HTML); **DataProtection persistido** (tokens sobrevivem a restart; `SetApplicationName("Identity")`; correção de ownership do volume `jwtkeys`); **celular por código numérico de 6 dígitos** (`phone_verification_codes`, hash SHA-256, 10 min, vínculo com o número — substitui o token nativo); diagnóstico do trial Twilio (482913 = template fixo, mantido); **`TenantModuleDto` sem `planName`** (plano só por FK `planId`); `SEED_SUPERADMIN_PASSWORD` alinhado; 118/118 testes |

## Decisões Estruturantes

- Identificação de branch (estratégia de multi-tenant/multi-filial) — pendente de definição
- Pacote de Identity/Acesso vs. OpenIddict (Open Source, free tier viável) — pendente de definição
- Provedor de SMS para validação de celular — **definido (Etapa 06)**: ISmsSender com Twilio trial + fallback de log em dev (limitação documentada)
- Política de expiração/renovação de tokens — definida na Etapa 03 (rotação de refresh)
- Confirmação de e-mail: **tokens nativos do Identity** (Etapa 06)
- Bloqueio de conta: **e-mail confirmado obrigatório**; celular informativo (Etapa 06)
- Observabilidade: **Serilog + Correlation ID**, health checks no Postgres, **rate limit**
  por IP no login/refresh, métricas **OpenTelemetry/Prometheus** (Etapa 07)
- Cache: **IMemoryCache** padrão; **Valkey/Redis** distribuído via `Cache:Mode=redis`
  (Etapa 07)
- Container: **Dockerfile non-root** (`app` UID 1654), **rede `identity-net`**,
  **`.env` fora do git** (só `.env.example` versionado), compose **base=prod** +
  **override=dev** (Etapa 08)
- Documentação/contrato: **OpenAPI v3.1 gerado nativamente** (`/openapi/v1.json`) +
  transformers de Bearer/autorização, **`CONTRATO-IDENTIDADE.md`** na raiz (Etapa 09)
- Testes: **xUnit + Testcontainers Postgres** (`tests/Identity.Tests`, fixture
  compartilhada na collection `"integration"`), implementação de `IEmailSender`/
  `ISmsSender` capturadores — **sem mocks de rede**, Postgres 100% real (Etapa 09)
- UI de documentação: **Scalar** (`Scalar.AspNetCore` 2.16.18, em `/scalar`,
  dev-only) no lugar do SwaggerUI; consome o OpenAPI nativo e habilita
  **Bearer JWT** na UI para testes manuais (Etapa 10)
- Credenciais externas: **NUNCA em `appsettings.json` versionado** — dev via
  `dotnet user-secrets`, prod via env `__`/secret manager; guia completo em
  `docs/CONFIGURACAO-CREDENCIAIS.md` (Etapa 10)
- Gestão de conta (Etapa 11): reset de senha por e-mail (token nativo, 30 min) e
  SMS (código 6 dígitos, 10 min), troca de senha autenticada, logout/logout-all
  com **revogação de refresh tokens no banco**; `register` público de Client
  (tenantId no body) com confirmação por e-mail
- Catálogo de roles: `GET /api/roles` (autenticado) devolve as roles da
  plataforma na ordem canônica (`Identity.Domain.Common.Roles`), lendo o banco
  via `RoleManager`; serviço em `IRoleService`/`RoleService` (namespace
  `RoleCatalog` — evita colisão com o tipo `Roles`)
- Plans (Etapa 12): domínio `Plan` + CRUD `/api/plans` **exclusivo SuperAdmin**;
  **soft delete** com **named query filter** (`HasQueryFilter("Active")`, ignorado
  via `IgnoreQueryFilters` para listar inativos); nome **único entre planos
  ativos** (índice parcial `IX_plans_name_active`); validação com **FluentValidation**
  (commands/queries como DTOs, sem MediatR — consistente com `IAuthService`)
- Tenants (Etapa 13): CRUD `/api/tenants` **exclusivo SuperAdmin**; FK
  **`plan_id` OPCIONAL** no nascimento (decisão do usuário; atribuível depois);
  soft delete com named query filter e **índices parciais** de CNPJ/e-mail
  (`WHERE is_active` — soft-deletado libera o valor); unicidade global reusa
  `TenantUniquenessValidator` (Etapa 04); login/refresh de usuários de tenant
  soft-deletado bloqueado (`401`)
- Filiais (Etapa 14): CRUD aninhado `/api/tenants/{tenantId}/branches`, roles
  SuperAdmin+TenantAdmin; **autorização por claim `tenant_id` do JWT** — sem claim
  (SuperAdmin global) opera em qualquer tenant, com claim a rota **deve** bater
  (senão 403); queries sempre escopadas por TenantId (sem vazamento entre
  tenants); soft delete no Branch com named query filter "Active"
- Módulos/Planos (Etapa 15): **`Module`** com **slug estável e imutável**
  (identificador usado pelos outros microsserviços); `Plan` pertence a **um**
  módulo (nome único **por módulo** entre ativos); **`Tenant.PlanId` removido** e
  substituído pelo vínculo **`TenantModule`** (`tenant_modules`) — no máximo UM
  vínculo ATIVO por (tenant, module), **troca de plano inativa a vigência atual e
  abre uma nova** (histórico p/ billing), desvincular preserva o histórico;
  `PlansController` aninhado em `/api/modules/{moduleId}/plans`; vínculos em
  `/api/tenants/{tenantId}/modules` **exclusivo SuperAdmin** (decisão do usuário;
  TenantAdmin não opera contratação); nomes de module/plan sempre resolvidos via
  `IgnoreQueryFilters(["Active"])`
- Tenant CPF/CNPJ (Etapa 17 — **correção da Etapa 02**): `Tenant.Cnpj` →
  `Tenant.Documento` (`TipoPessoa` Fisica/Juridica + número); VO `Documento`
  reutiliza `Cpf`/`Cnpj`; **unicidade global pelo NÚMERO** (`IX_tenants_documento`,
  único parcial `WHERE is_active`, sem o tipo — independente de CPF/CNPJ);
  `CreateTenantCommand`/`TenantDto`/`ListTenantsQuery` e filtro `?documento=`;
  mensagens diferenciadas (CPF vs CNPJ); migration defensiva com backfill
  (existente = `Juridica`, sem default 0 inválido gerado pelo `dotnet ef`);
  documento imutável no PUT; `PtBrIdentityErrorDescriber` sem mudanças
- Seed inicial (Etapa 18): `DbSeeder` (`Seed/DbSeeder.cs`, idempotente, roda na
  inicialização em escopo próprio) cria Module `core` → Plan Full Access
  (R$ 0,00, limites `null`) → Tenant SmartSync Platform (pessoa física, CPF
  `295.584.478-03`) → Branch → vínculo `TenantModule` ativo → SuperAdmin global
  `sa@smartsync.com.br` (`TenantId` nulo, JWT sem `tenant_id`); **convenção
  `null` = "sem limite"** nos limites do plano (`int?`, migration
  `MakePlanLimitsNullable`); senha via **`SEED_SUPERADMIN_PASSWORD`** (default
  apenas em Development; fora de Development sem a variável o usuário não é
  criado); `IdentitySeeder` = migrations + roles; e-mail de bootstrap fixo
  `sa@smartsync.com.br` (substituiu `admin@identity.local` em compose/.env/docs)
- Correções pós-entrega (Etapa 19): **e-mail** com log de sucesso no
  `SmtpEmailSender` e `resend-confirmation-email` logando o motivo quando nada
  é enviado; **link de confirmação aponta para a API**
  (`/api/auth/confirm-email`) com novo **GET** devolvendo página HTML (o POST
  permanece); **DataProtection persistido** em `DataProtection:KeyPath`
  (volume), `SetApplicationName("Identity")`, com correção do **ownership do
  volume `jwtkeys`** (root→app) — tokens passaram a sobreviver a restarts;
  **celular por código numérico de 6 dígitos** (`phone_verification_codes`,
  hash SHA-256, 10 min, invalidação de anteriores, vínculo com o número)
  substituindo o token nativo do Identity; trial Twilio mantido (template fixo
  `sms_2fa`; código real só após upgrade); **`TenantModuleDto` sem `planName`**
  (plano apenas por FK `planId`); `SEED_SUPERADMIN_PASSWORD` alinhado à senha
  real do SuperAdmin

## Possível Evolução Futura (não implementada)

- **Passkeys / WebAuthn**: o ASP.NET Core Identity no .NET 10 ganhou suporte
  nativo a passkeys. Não implementado nesta etapa (decisão consciente). Avaliar
  como evolução futura do fluxo de autenticação.
- **OAuth2/OIDC / OpenIddict**: hoje a autorização é JWT próprio (RS256 + JWKS)
  validado pela rede interna. OpenIddict já foi considerado (Etapa 00) como
  alternativa para expor a identidade como provedor OIDC. Decisão futura.

## Pendências que dependem do usuário (Etapa 11)

- **Estratégia de revogação de refresh tokens** — **confirmada** (Etapa 11):
  armazenamento em banco (`refresh_tokens`, hash SHA-256) + revogação por valor
  no `logout` e em massa no `logout-all`/`change-password`/`reset-password`.
  **Sem denylist de JWT em memória/Redis** (access token sobrevive até os 15 min).
- ~~**Lifespan do token de reset por e-mail**~~ — **decidido** (Etapa 11):
  **30 min** via `DataProtectionTokenProviderOptions.TokenLifespan` (também vale
  para o token de confirmação de e-mail, mesmo provider).
- **Cadastro de roles internas** (Manager/Seller/Delivery/TenantAdmin): o
  **catálogo** `GET /api/roles` existe; falta apenas o endpoint de **criação**
  de roles/usuários internos (futuros endpoints de admin).
- **Credenciais externas a criar/configurar** (guia: `docs/CONFIGURACAO-CREDENCIAIS.md`):
  - Google Cloud OAuth Client ID/Secret (Web app, redirect `signin-google`);
  - Facebook for Developers App ID/Secret (Login, redirect `signin-facebook`);
  - Twilio trial (Account SID/Auth Token/número de origem + número verificado);
  - Gmail pessoal (**decidido**): verificação em 2 etapas + **Senha de App**.
- **Migração futura**: se a conta de e-mail for workspace, fluxo muda para OAuth2
  (XOAUTH2) no `SmtpEmailSender` — documentado, sem implementação.
- **Teste end-to-end real** (SSO Google/Facebook, SMS, e-mail) pendente até as
  credenciais existirem em dev.

## Pendências registradas na Etapa 13

- **Sessões/refresh tokens de usuários de um tenant soft-deletado/editado**
  (tarefa 4 da Etapa 13 — **não tratado agora, registrado**): o login/refresh é
  bloqueado no momento da tentativa (`401`), mas **refresh tokens já emitidos
  continuam válidos** (e access tokens até os 15 min). Sem revogação em massa
  por tenant. Decisões futuras: revogar os refresh tokens dos usuários do tenant
  no soft delete; bloquear também para `Status = Inactive/Suspended`.
- **Limites do plano** (`MaxBranches`/`MaxUsers`/`MaxStorageMb`) ainda não são
  aplicados no cadastro de filiais/usuários (próximo passo natural).

## Pendências registradas na Etapa 15

- **Como os outros microsserviços consultam o acesso do tenant a um módulo**
  (pendência da Etapa 15): os endpoints de vínculo são SuperAdmin-only. Decidir
  entre: (a) endpoint do próprio tenant `GET /api/tenants/me/modules` (por
  claim `tenant_id`); (b) consulta direta ao banco pelo microsserviço; (c)
  propagação para o billing. Registrado, pendente.
  - **Etapa 16:** a opção **(a)** foi documentada como **contrato recomendado**
    em `docs/CONTRATO-IDENTIDADE.md` (§12) — endpoint planejado, **ainda não
    implementado**; consulta direta ao banco segue proibida. Implementação é
    pendência da Etapa 17.

## Pendências registradas na Etapa 16

- **`GET /api/tenants/me/modules`** (contrato recomendado documentado em
  `docs/CONTRATO-IDENTIDADE.md` §12) — **implementar** (qualquer role do tenant
  autenticada por claim `tenant_id`; retorna módulos ativos com `slug`/`plan`
  para ligar/desligar features e aplicar limites). Continua pendente após a
  Etapa 17 (que tratou do documento do tenant, não deste endpoint).
- ~~**`docs/DEV-CREDENTIALS.md`**~~ — **resolvido** (Etapa 16): recriado com as
  credenciais padrão de dev (SuperAdmin, login, registro por `type` e SSO).
- ~~**Duplicado obsoleto na raiz**~~ (`CONTRATO-IDENTIDADE.md` v1.1/Etapa 11) —
  **resolvido** (Etapa 16): arquivo **removido**; o contrato oficial é o único
  em `docs/CONTRATO-IDENTIDADE.md`.

## Pendências registradas na Etapa 17

- **`GET /api/tenants/me/modules`** — segue pendente (ver acima).
- **Limites do plano** (`MaxBranches`/`MaxUsers`/`MaxStorageMb`) ainda não
  aplicados no cadastro de filiais/usuários (pendência das Etapas 13/14/15).
- **Revogação em massa de refresh tokens por tenant** no soft delete do tenant
  (pendência da Etapa 13).
- **Documento do usuário** (`ApplicationUser.Document`) segue como string livre
  (CPF/CNPJ por role, Etapa 03) — não foi unificado com o VO `Documento` do
  tenant nesta etapa.

## Pendências registradas na Etapa 18

- **`GET /api/tenants/me/modules`** — segue pendente (ver acima).
- **Aplicar os limites do plano** (`MaxBranches`/`MaxUsers`/`MaxStorageMb`) no
  cadastro de filiais/usuários — agora com suporte a `null` = sem limite
  (Etapa 18), a aplicação deve ignorar limites nulos.
- **Revogação em massa de refresh tokens por tenant** no soft delete do tenant
  (pendência da Etapa 13).
- **Documento do usuário** (`ApplicationUser.Document`) segue como string livre
  (CPF/CNPJ por role, Etapa 03) — não foi unificado com o VO `Documento` do
  tenant.
- **Telefone da filial de bootstrap** é placeholder (`docs/SEED-INICIAL.md`
  documenta) — validar com o valor real antes de expor a produção.

## Pendências registradas na Etapa 19

- **Teste de integração** para `send-sms-code`/`confirm-phone` (fluxo validado
  manualmente em execução real; sem teste automatizado).
- **Após o upgrade da conta Twilio**: esvaziar `SMS_BODY_TEMPLATE` no `.env` e
  recriar o container para o código real de 6 dígitos ir no SMS.
- **Twilio Verify** registrado como alternativa de OTP que funciona no trial
  (envia código aleatório real; exige `ServiceSid` + número verificado) — não
  implementado.
- Pendências anteriores que **seguem abertas**: `GET /api/tenants/me/modules`;
  limites do plano não aplicados no cadastro de filiais/usuários; revogação em
  massa de refresh tokens por tenant no soft delete; `ApplicationUser.Document`
  como string livre.

## Como adicionar uma nova etapa

1. Crie `etapa-XX-nome-da-etapa.md` (numeração sequencial `01`, `02`, ...).
2. Adicione uma linha na tabela `Histórico de Etapas` deste índice.
3. Atualize `Última atualização` no topo deste arquivo.